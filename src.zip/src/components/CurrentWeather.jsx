

const CurrentWeather = (props) => {
  if (!props.weatherData) {
    return <div className="rounded-2xl bg-slate-800 p-6 text-slate-300">
    Search for a city to see its weather</div>;
  }
    const weatherCode = () => {
      const code = props.weatherData.current.weather_code;
      if (code === 0) return "Clear sky";
      if (code === 1) return "Mainly clear";
      if (code === 2) return "Partly Cloudy";
      if (code === 3) return "overcast";
      if (code === 61) return "Slight rain";
      return "Unknown weather condition";
    };
      
  return (
    <div className="rounded-2xl bg-slate-800 p-6 md:p-8">
      <p className="text-lg font-medium text-slate-300">{props.city}</p>
      <div className="mt-4">
        <h2 className="text-5xl font-semibold tracking-tight text-white md:text-6xl">{props.weatherData.current.temperature_2m}°C</h2>
        <p className="mt-3 text-lg text-slate-400">Feels like {props.weatherData.current.apparent_temperature}°C</p>
        <p className="mt-2 text-base font-medium text-sky-300">{weatherCode()}</p>
  
      </div>

    </div>
  )
}

export default CurrentWeather
